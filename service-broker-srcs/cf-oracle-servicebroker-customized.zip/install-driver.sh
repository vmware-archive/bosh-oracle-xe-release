 mvn install:install-file -Dfile=ojdbc.12.6.6.6.jar -DgroupId=com.oracle -DartifactId=ojdbc -Dversion=12.6.6.6 -Dpackaging=jar
