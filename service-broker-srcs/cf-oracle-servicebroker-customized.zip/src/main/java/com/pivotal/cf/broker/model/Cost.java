package com.pivotal.cf.broker.model;

import org.springframework.util.Assert;

import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.Table;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
@JsonAutoDetect(getterVisibility = JsonAutoDetect.Visibility.NONE)
final class Cost {

  @Id
  private String id;

  @ManyToOne(cascade = CascadeType.PERSIST)
  @JsonIgnore
  private PlanMetadata planMetadata;

  public PlanMetadata getPlanMetadata() {
    return planMetadata;
  }

  public void setPlanMetadata(PlanMetadata planMetadata) {
    this.planMetadata = planMetadata;
  }

  // any "other" tags/key-value pairs
  @JsonSerialize
  @JsonProperty("amount")
  @ElementCollection(fetch = FetchType.EAGER)
  @MapKeyColumn(name="currency")
    @Column(name="value")
    @CollectionTable(name="cost_amounts", joinColumns=@JoinColumn(name="plan_metadata_id"))
  private Map<String,Double> amount = new HashMap<String,Double>();

  @JsonProperty("unit")
  private String unit = "MONTHLY";

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setAmount(Map<String, Double> amount) {
    this.amount = amount;
  }

  public Map<String, Double> getAmount() {
        Assert.notEmpty(this.amount, "Cost must specify at least one amount");
        return this.amount;
    }

  public String getUnit() {
        Assert.notNull(this.unit, "Cost must specify a unit");
        return this.unit;
    }

  public void setAmount(String currency, Double value) {
        this.amount.put(currency, value);
    }

    @JsonAnySetter
    public void set(String currency, Double value) {
      amount.put(currency, value);
    }

    void setUnit(String unit) {
        this.unit = unit;
    }

    public void update(Cost from) {
    if (from == null)
      return;

    if (from.amount != null) {
      for(String key: amount.keySet()) {
        this.set(key, amount.get(key));
      }
    }

  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Cost other = (Cost) obj;
    if (id != other.id)
      return false;
    return true;
  }




}

