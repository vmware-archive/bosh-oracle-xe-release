package com.pivotal.cf.broker.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.pivotal.cf.broker.model.CreateServiceInstanceRequest;
import com.pivotal.cf.broker.model.Plan;
import com.pivotal.cf.broker.model.ServiceDefinition;
import com.pivotal.cf.broker.model.ServiceInstance;
import com.pivotal.cf.broker.model.ServiceInstanceBinding;
import com.pivotal.cf.broker.model.ServiceInstanceBindingRequest;
import com.pivotal.cf.broker.repositories.PlanRepository;
import com.pivotal.cf.broker.repositories.ServiceDefinitionRepository;
import com.pivotal.cf.broker.repositories.ServiceInstanceBindingRepository;
import com.pivotal.cf.broker.repositories.ServiceInstanceRepository;
import com.pivotal.cf.broker.services.BaseService;
import com.pivotal.cf.broker.services.ServiceManagement;
import com.pivotal.cf.broker.services.TemplateService;
import com.pivotal.cf.broker.utils.StringUtils;

@Service
public class ServiceManagementImpl extends BaseService implements ServiceManagement {
	@Autowired
	private PlanRepository planRepository;
	
	@Autowired
	private ServiceDefinitionRepository serviceRepository;
	
	@Autowired 
	private ServiceInstanceRepository serviceInstanceRepository;
	
	@Autowired 
	private ServiceInstanceBindingRepository bindingRepository;
	
	@Autowired
	TemplateService templateService;
	
	@Autowired
	private Environment env;
	
	private HashMap<String, Integer> servicePlanCapacityMap = new HashMap<String, Integer>();
	
	private static int MAX_CAPACITY_LIMIT = 200;
	private static Object lockObject = new Object();
	private static final Logger log = Logger.getLogger(ServiceManagement.class);
	
	@Override
	public ServiceInstance createInstance(CreateServiceInstanceRequest serviceRequest) {
		ServiceDefinition serviceDefinition = serviceRepository.findOne(serviceRequest.getServiceDefinitionId());
		if(serviceDefinition == null){
			throw new IllegalArgumentException("Service definition not found: " + serviceRequest.getServiceDefinitionId());
		}
		Plan plan = planRepository.findOne(serviceRequest.getPlanId());
		if(plan == null){
			throw new IllegalArgumentException("Invalid plan identifier");
		}
		if(serviceInstanceRepository.exists(serviceRequest.getServiceInstanceId())){
			throw new IllegalStateException("There's already an instance of this service");
		}
		
		synchronized(lockObject) {
			int capacityUtilized = listUsage();
			int capacityRequested = new Integer(plan.getMetadata().getOther().get("connections"));
			
			if ((capacityUtilized + capacityRequested) > MAX_CAPACITY_LIMIT) {
				String errorMsg = "No more capacity available, already alloted : " + capacityUtilized 
						+ ", max limit: " + MAX_CAPACITY_LIMIT;
						
				log.error(errorMsg);
				throw new IllegalStateException(errorMsg);
			}
		}
		
		ServiceInstance instance = new ServiceInstance(serviceRequest.getServiceInstanceId(), serviceDefinition.getId(), plan.getId(), serviceRequest.getOrganizationGuid(), serviceRequest.getSpaceGuid(), "");
		String tablespaceName = StringUtils.randomString(12);
		instance.getConfig().put("tablespace",tablespaceName);
		Map<String,Object> model = new HashMap<String, Object>();
		model.put("plan",plan);
		model.put("instance",instance);
		templateService.execute("instance/create.ftl", model);
		instance = serviceInstanceRepository.save(instance);
		return instance;
	}

	@Override
	public boolean removeServiceInstance(String serviceInstanceId) {
		if(!serviceInstanceRepository.exists(serviceInstanceId)){
			return false;
		}
		if(bindingRepository.countByServiceInstanceId(serviceInstanceId) > 0){
			throw new IllegalStateException("Can not delete service instance, there are still apps bound to it");
		}
		ServiceInstance instance = serviceInstanceRepository.findOne(serviceInstanceId);
		Map<String,Object> model = new HashMap<String, Object>();
		model.put("instance",instance);
		templateService.execute("instance/delete.ftl", model);
		
		serviceInstanceRepository.delete(serviceInstanceId);
		return true;
	}

	@Override
	public List<ServiceInstance> listInstances() {
		return makeCollection(serviceInstanceRepository.findAll());
	}

	@Override
	public synchronized int listUsage() {
		loadCapacityMap();
		
		AtomicInteger capacityUtilized = new AtomicInteger();
		for(ServiceInstance instance :serviceInstanceRepository.findAll()) {
			String key = instance.getServiceDefinitionId() + ":" + instance.getPlanId();
			capacityUtilized.addAndGet(servicePlanCapacityMap.get(key).intValue());
		}
		log.info("Current capacity under utilization: " + capacityUtilized.get());
		return capacityUtilized.get();
	}

	private synchronized void loadCapacityMap() {
		if (servicePlanCapacityMap.size() != 0) {
			return;
		}
		
		for(ServiceDefinition service: serviceRepository.findAll()) {
			List<Plan> plans = service.getPlans();
			for(Plan plan: plans) {
				String key = service.getId() + ":" + plan.getId();
				Integer capacity = servicePlanCapacityMap.get(key);
				if (capacity == null || capacity.intValue() == 0) {
					//log.debug("Plan metdata theOther contains: " + plan.getMetadata().getOther().toString());
					capacity = new Integer(plan.getMetadata().getOther().get("connections"));
					servicePlanCapacityMap.put(key, capacity);
					log.debug("Added " + key + " with capacity: " + capacity);
				}
			}
		}
	}

	@Override
	public ServiceInstanceBinding createInstanceBinding(ServiceInstanceBindingRequest bindingRequest) {
		if(bindingRepository.exists(bindingRequest.getBindingId())){
			throw new IllegalStateException("Binding Already exists");
		}
		
		Map<String, String> credentials = new HashMap<String, String>();
		credentials.put("username", StringUtils.randomString(8));
		credentials.put("password",StringUtils.randomString(12));
		credentials.put("hostname", env.getProperty("oracle.host"));
		credentials.put("port", env.getProperty("oracle.port"));
		credentials.put("name",env.getProperty("oracle.service"));
		credentials.put("uri","oracle://"+credentials.get("username")+":"+credentials.get("password")+"@"+credentials.get("hostname")+":"+credentials.get("port")+"/"+credentials.get("name"));
		ServiceInstanceBinding binding = new ServiceInstanceBinding();
		binding.setId(bindingRequest.getBindingId());
		binding.setServiceInstanceId(bindingRequest.getInstanceId());
		binding.setAppGuid(bindingRequest.getAppGuid());
		binding.setCredentials(credentials);
		ServiceInstance instance = serviceInstanceRepository.findOne(bindingRequest.getInstanceId());
		Plan plan = planRepository.findOne(bindingRequest.getPlanId());
		Map<String,Object> model = new HashMap<String, Object>();
		model.put("plan",plan);
		model.put("binding",binding);
		model.put("instance",instance);
		templateService.execute("binding/create.ftl", model);
		binding = bindingRepository.save(binding);
		return binding;
	}

	@Override
	public boolean removeBinding(String serviceBindingId) {
		ServiceInstanceBinding binding = bindingRepository.findOne(serviceBindingId);
		if(binding == null){
			return false;
		}
		Map<String,Object> model = new HashMap<String, Object>();
		model.put("binding",binding);
		templateService.execute("binding/delete.ftl", model);
		bindingRepository.delete(binding);
		return true;
	}

	@Override
	public List<ServiceInstanceBinding> listBindings() {
		// TODO Auto-generated method stub
		return null;
	}

}
